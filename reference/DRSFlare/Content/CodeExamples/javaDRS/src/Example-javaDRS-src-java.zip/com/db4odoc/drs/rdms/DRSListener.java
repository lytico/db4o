package com.db4odoc.drs.rdms;


public class DRSListener {
}
