namespace Db4oDoc.Silverlight.Model
{
    // #example: fields need to be public to be persisted
    public class Person
    {
        public string FirstName;
        public string SirName;
    }
    // #end example
}