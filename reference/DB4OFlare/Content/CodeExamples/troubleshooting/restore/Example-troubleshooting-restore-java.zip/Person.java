package com.db4odoc.troubleshooting.restore;


class Person {
    private String name;

    Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
