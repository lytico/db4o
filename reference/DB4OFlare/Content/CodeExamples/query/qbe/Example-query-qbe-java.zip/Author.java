package com.db4odoc.query.qbe;


class Author {
    private String name;

    Author(String name) {
        this.name = name;
    }
}
