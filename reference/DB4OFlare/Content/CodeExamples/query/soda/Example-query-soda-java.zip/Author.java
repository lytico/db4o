package com.db4odoc.query.soda;


class Author {
    private String name;

    Author(String name) {
        this.name = name;
    }
}
