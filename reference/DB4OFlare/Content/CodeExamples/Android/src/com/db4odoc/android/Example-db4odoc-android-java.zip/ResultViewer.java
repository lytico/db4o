package com.db4odoc.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultViewer extends Activity {
	TextView console;
	TextView consoleDb4o;
	TextView consoleSql;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle icicle) {

		

	}
}