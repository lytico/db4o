﻿using Db4objects.Db4o;
using Db4objects.Db4o.CS;
using Db4objects.Db4o.CS.Config;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Config.Encoding;
using OMCustomConfigurationforUser;

namespace Db4oDoc.Code.OMN
{
    // #example: Configuration for embedded database
    public class ConfigForEmbedded : IOMNEmbeddedCustomConfigurationProvider
    {
        public IEmbeddedConfiguration NewEmbeddedCustomConfiguration()
        {
            var config = Db4oEmbedded.NewConfiguration();
            config.Common.StringEncoding = StringEncodings.Utf8();
            return config;
        }
    }
    // #end example
    // #example: Configuration for a client connection
    public class ConfigForClient : IOMNClientCustomConfigurationProvider
    {
        public IClientConfiguration NewClientCustomConfiguration()
        {
            var config = Db4oClientServer.NewClientConfiguration();
            config.Common.StringEncoding = StringEncodings.Utf8();
            return config;
        }
    }   
    // #end example
}