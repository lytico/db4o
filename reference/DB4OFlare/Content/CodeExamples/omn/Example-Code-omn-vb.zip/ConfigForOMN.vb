﻿Imports Db4objects.Db4o
Imports Db4objects.Db4o.CS
Imports Db4objects.Db4o.CS.Config
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Config.Encoding
Imports OMCustomConfigurationforUser

Namespace Db4oDoc.Code.OMN
    ' #example: Configuration for embedded database
    Public Class ConfigForEmbedded
        Implements IOMNEmbeddedCustomConfigurationProvider
        Public Function NewEmbeddedCustomConfiguration() As IEmbeddedConfiguration _
            Implements IOMNEmbeddedCustomConfigurationProvider.NewEmbeddedCustomConfiguration
            Dim config = Db4oEmbedded.NewConfiguration()
            config.Common.StringEncoding = StringEncodings.Utf8()
            Return config
        End Function
    End Class
    ' #end example
    ' #example: Configuration for a client connection
    Public Class ConfigForClient
        Implements IOMNClientCustomConfigurationProvider
        Public Function NewClientCustomConfiguration() As IClientConfiguration _
            Implements IOMNClientCustomConfigurationProvider.NewClientCustomConfiguration
            Dim config = Db4oClientServer.NewClientConfiguration()
            config.Common.StringEncoding = StringEncodings.Utf8()
            Return config
        End Function
    End Class
    ' #end example
End Namespace
