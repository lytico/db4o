package com.db4odoc.configuration.objectconfig;


public class Person {
}
