package com.db4odoc.configuration.objectfield;

class Person {
    private String name;
    private Person father;

}
