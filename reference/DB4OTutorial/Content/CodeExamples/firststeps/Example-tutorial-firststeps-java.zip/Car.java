package com.db4odoc.tutorial.firststeps;


// #example: Domain model for cars
public class Car {
    private String carName;

    public Car(String carName) {
        this.carName = carName;
    }

}
// #end example
