package com.db4odoc.tutorial.transparentpersistence;


@TransparentPersisted
public class ClassWithAnnotation {
}
