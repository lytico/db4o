package com.db4odoc.tutorial.transparentpersistence;

public class ClassWithoutAnnotation {
}
